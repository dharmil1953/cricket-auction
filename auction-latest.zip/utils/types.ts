export type buyersProps = {
  id: number;
  name: string;
  balance: number;
};
