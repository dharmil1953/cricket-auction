import AuctionPage from "@/components/AuctionPage";
import Navbar from "@/components/Navbar";
import Image from "next/image";

export default function Home() {
  return (
    <div>
      <Navbar />
      <AuctionPage />
    </div>
  );
}
