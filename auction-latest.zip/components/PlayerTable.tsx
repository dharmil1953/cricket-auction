import React from "react";

const PlayerTable = () => {
  return <div>PlayerTable</div>;
};

export default PlayerTable;
