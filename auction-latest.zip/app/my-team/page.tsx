import MyTeam from "@/components/MyTeam";
import Navbar from "@/components/Navbar";
import React from "react";

const allPlayers = () => {
  return (
    <div>
      <Navbar />
      <MyTeam />
    </div>
  );
};

export default allPlayers;
