"use client";
import useSupabase from "@/utils/hooks/useSupabase";
import useUser from "@/utils/hooks/useUser";
import React, { useEffect, useState } from "react";

interface Player {
  id: number;
  name: string;
  image_url: string;
  base_price: number;
  batting_rating: number;
  bowling_rating: number;
  status: string;
  team_id: number;
  sold: boolean;
}

interface Bid {
  buyer_id: string;
  total_bid_amount: number;
  bids: string[];
}

const AuctionPage = () => {
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [bids, setBids] = useState<Bid[]>([]);
  const [currentBid, setCurrentBid] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [isBiddingActive, setIsBiddingActive] = useState<boolean>(false);
  const supabase = useSupabase();
  const user = useUser();

  useEffect(() => {
    const fetchPlayers = async () => {
      if (supabase) {
        try {
          const { data, error } = await supabase.from("players").select("*");
          if (error) throw new Error(error.message);
          setPlayers(data);
        } catch (err) {
          setError("Failed to fetch players.");
        } finally {
          setLoading(false);
        }
      }
    };
    fetchPlayers();
  }, [supabase]);

  useEffect(() => {
    let timer: NodeJS.Timeout;

    if (timeLeft > 0 && isBiddingActive) {
      timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            setIsBiddingActive(false);
            handleBiddingComplete();
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (timer) clearInterval(timer);
    };
  }, [timeLeft, isBiddingActive]);

  useEffect(() => {
    if (!selectedPlayer) return;

    const fetchExistingBids = async () => {
      const { data, error } = await supabase
        .from("players_bid")
        .select("*")
        .eq("id", selectedPlayer.id);

      console.log("Fetched bids:", data);
      console.log(
        "selectedPlayer.base_price",
        data[data.length - 1].total_bid_amount
      );

      if (!error && data) {
        setBids(data as Bid[]);
        if (data.length > 0) {
          setCurrentBid(data[0].total_bid_amount);
        } else {
          setCurrentBid(selectedPlayer.base_price);
        }
      }
    };

    fetchExistingBids();

    const bidsSubscription = supabase
      .channel(`player-bids-${selectedPlayer.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "players_bid",
          filter: `player_id=eq.${selectedPlayer.id}`,
        },
        (payload: any) => {
          const newBid = payload.new as Bid;
          setBids((prevBids) => [...prevBids, newBid]);
          setCurrentBid(newBid.total_bid_amount);
        }
      )
      .subscribe();

    return () => {
      bidsSubscription.unsubscribe();
    };
  }, [selectedPlayer, supabase]);

  const startBidding = async (player: Player) => {
    console.log("Selected player:", player);
    setSelectedPlayer(player);
    setTimeLeft(30);
    setIsBiddingActive(true);
    setCurrentBid(player.base_price);
    setBids([]);
  };

  const handleBiddingComplete = async () => {
    if (!selectedPlayer || !bids.length) return;

    const highestBid = bids.reduce((max, bid) =>
      bid.total_bid_amount > max.total_bid_amount ? bid : max
    );

    // try {
    //   await supabase
    //     .from("players")
    //     .update({
    //       sold: true,
    //       team_id: highestBid.buyer_id,
    //     })
    //     .eq("id", selectedPlayer.id);

    //   setPlayers((prevPlayers) =>
    //     prevPlayers.map((p) =>
    //       p.id === selectedPlayer.id ? { ...p, sold: true } : p
    //     )
    //   );

    //   setSelectedPlayer(null);
    // } catch (error) {
    //   console.error("Error completing auction:", error);
    // }
  };

  const handleBidding = async (incrementAmount: number) => {
    console.log("Current bid before increment:", currentBid);
    if (user && selectedPlayer) {
      try {
        const { data: currentData, error: fetchError } = await supabase
          .from("buyers")
          .select("*")
          .eq("id", user?.user?.id)
          .single();

        if (fetchError) throw new Error(fetchError.message);
        console.log("user?.user?.id", user?.user?.id);

        const totalBidAmount = currentBid + incrementAmount;

        if (currentData?.balance < totalBidAmount) {
          alert("Insufficient balance!");
          return;
        }

        // const updatedTeamList = [
        //   ...(currentData?.team_list || []),
        //   selectedPlayer.id,
        // ];

        // const { data, error } = await supabase
        //   .from("buyers")
        //   .update({ team_list: updatedTeamList })
        //   .eq("id", user?.user?.id);

        // if (error) throw new Error(error.message);

        // const { data: playerData, error: playerError } = await supabase
        //   .from("players")
        //   .update({ team_id: user?.user?.id, sold: true })
        //   .eq("id", selectedPlayer.id);
        console.log("totalBidAmount", totalBidAmount);
        console.log("currentBid", currentBid);
        console.log("bids", bids);

        const newBid: Omit<Bid, "id"> = {
          buyer_id: user?.user?.id,
          total_bid_amount: totalBidAmount,
          bids: [
            ...(bids?.[bids.length - 1]?.bids || []),
            `Bid: ${incrementAmount} by ${currentData.name}}`,
          ],
        };
        console.log("newBid", newBid);

        const { data, error: bidError } = await supabase
          .from("players_bid")
          .insert({
            ...newBid,
            id: selectedPlayer.id,
          });

        const updatedBalance = currentData.balance - totalBidAmount;

        const { data: balanceData, error: balanceError } = await supabase
          .from("buyers")
          .update({ balance: updatedBalance })
          .eq("id", user?.user?.id);

        // setBids([
        //   ...bids,
        //   {
        //     buyer_name: currentData.name || "Unknown Buyer",
        //     amount: totalBidAmount,
        //     timestamp: new Date(),
        //   },
        // ]);

        // setPlayers(
        //   players.map((p) =>
        //     p.id === selectedPlayer.id ? { ...p, sold: true } : p
        //   )
        // );
      } catch (err) {
        console.error("Failed to place bid:", err);
      }
      alert("Bid placed");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-gray-900 to-gray-800">
        <div className="text-2xl font-bold text-white animate-pulse">
          Loading Auction House...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800">
      <div className="container mx-auto p-6 mb-8">
        {selectedPlayer && (
          <div className="bg-black bg-opacity-90 rounded-lg overflow-hidden">
            <div className="text-center p-4">
              <div
                className={`text-2xl font-bold ${
                  timeLeft <= 10 ? "text-red-500" : "text-white"
                }`}
              >
                {timeLeft > 0
                  ? `Time Remaining: ${timeLeft}s`
                  : "Bidding Closed"}
              </div>
            </div>
            <div className="grid grid-cols-3 gap-0">
              <div className="p-6 border-r border-gray-800">
                <h3 className="text-xl font-bold text-white mb-4">
                  Current Bids
                </h3>
                <div className="space-y-3">
                  {bids.map((bid, index) => (
                    <div
                      key={index}
                      className="flex justify-between items-center text-sm"
                    >
                      <span className="text-gray-400">{bid.buyer_id}</span>
                      <span className="text-yellow-500">
                        ₹{bid.total_bid_amount?.toLocaleString()}
                      </span>
                    </div>
                  ))}
                  {bids.length === 0 && (
                    <div className="text-gray-400">No bids placed yet.</div>
                  )}
                </div>
                <div className="mt-4 p-4 bg-gray-800 rounded-lg text-center">
                  <h4 className="text-lg font-bold text-white">Total Bids</h4>
                  <div className="text-yellow-500 font-bold text-2xl">
                    ₹
                    {bids
                      .reduce((total, bid) => total + bid.total_bid_amount, 0)
                      ?.toLocaleString()}
                  </div>
                </div>
              </div>

              <div className="flex flex-col items-center justify-center p-6">
                <div className="relative w-48 h-48">
                  <img
                    src={selectedPlayer.image_url}
                    alt={selectedPlayer.name}
                    className="w-48 h-48 rounded-full object-cover border-4 border-yellow-500"
                  />
                </div>
                <h2 className="text-2xl font-bold text-white mt-4">
                  {selectedPlayer.name}
                </h2>
                <div className="text-3xl font-bold text-yellow-500 mt-2">
                  Current Bid: ₹{currentBid?.toLocaleString()}
                </div>
              </div>

              <div className="p-6 border-l border-gray-800">
                <div className="space-y-2">
                  <div className="text-sm">
                    <span className="text-gray-400">Base Price: </span>
                    <span className="text-white">
                      ₹{selectedPlayer.base_price?.toLocaleString()}
                    </span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-400">Batting Rating: </span>
                    <span className="text-white">
                      {selectedPlayer.batting_rating}
                    </span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-400">Bowling Rating: </span>
                    <span className="text-white">
                      {selectedPlayer.bowling_rating}
                    </span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-400">Status: </span>
                    <span className="text-white">{selectedPlayer.status}</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-400">Country: </span>
                    <span className="text-white">IND</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-400">IPL 2024: </span>
                    <span className="text-white">DC</span>
                  </div>
                </div>
                {isBiddingActive && (
                  <>
                    <button
                      onClick={() => handleBidding(5000)}
                      className="w-full mt-6 py-3 bg-yellow-500 hover:bg-yellow-600 text-black font-bold rounded"
                    >
                      Place Bid (₹5,000)
                    </button>
                    <div className="flex gap-5 text-black my-5 font-bold">
                      <span
                        className="bg-yellow-500 rounded-2xl p-2 cursor-pointer"
                        onClick={() => handleBidding(10000)}
                      >
                        +10,000 ₹
                      </span>
                      <span
                        className="bg-yellow-500 rounded-2xl p-2 cursor-pointer"
                        onClick={() => handleBidding(20000)}
                      >
                        +20,000 ₹
                      </span>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {players
            .filter((player) => !player.sold)
            .map((player) => (
              <div
                key={player.id}
                className="bg-black bg-opacity-50 p-4 rounded-lg shadow-lg text-center"
              >
                <img
                  src={player.image_url}
                  alt={player.name}
                  className="w-32 h-32 object-cover rounded-full mx-auto mb-4"
                />
                <h3 className="text-lg font-semibold text-white mb-2">
                  {player.name}
                </h3>
                <div className="text-yellow-500 font-bold mb-2">
                  ₹{player.base_price?.toLocaleString()}
                </div>
                <button
                  className={`px-4 py-2 mt-2 text-white rounded-lg
                  ${
                    !player.sold
                      ? "bg-yellow-500 hover:bg-yellow-600"
                      : "bg-gray-500 cursor-not-allowed"
                  }`}
                  onClick={() => startBidding(player)}
                  disabled={player.sold || isBiddingActive}
                >
                  {player.sold ? "SOLD" : "Start Bidding"}
                </button>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default AuctionPage;
